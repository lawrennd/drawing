function ovals = ovalMove(ovals, moveVector);

% OVALMOVE Moves a oval to a new point.
%
%	Description:
%	ovals = ovalMove(ovals, moveVector);
%% 	ovalMove.m version 1.2


for i = 1:length(ovals)
  ovals(i).centre = ovals(i).centre + moveVector;
  ovals(i) = ovalDraw(ovals(i));
end