function rect = rectCreate(firstPoint, secondPoint, handle);

% RECTCREATE Create a struct containing the parameters of an rectangle.
%
%	Description:
%	rect = rectCreate(firstPoint, secondPoint, handle);
%% 	rectCreate.m version 1.2


rect.firstPoint = firstPoint;
rect.secondPoint = secondPoint;
rect.selected = 1;
if nargin > 2
  rect.handle = handle;
end

rect.type = 'rect';

