function newOval = ovalCopy(oval);

% OVALCOPY Copies a oval structure into a new oval structure.
%
%	Description:
%	newOval = ovalCopy(oval);
%% 	ovalCopy.m version 1.2


newOval = oval;
newOval.handle = [];
newOval.controlPointHandle = [];