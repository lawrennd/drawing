function object = objectMove(object, moveVector);

% OBJECTMOVE Moves an object to a new point.
%
%	Description:
%	object = objectMove(object, moveVector);
%% 	objectMove.m version 1.2


object = feval([object.type 'Move'], object, moveVector);
