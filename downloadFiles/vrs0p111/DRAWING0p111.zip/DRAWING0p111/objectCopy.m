function newObject = objectCopy(object);

% OBJECTCOPY Moves an object to a new point.
%
%	Description:
%	newObject = objectCopy(object);
%% 	objectCopy.m version 1.3


newObject = feval([object.type 'Copy'], object);
