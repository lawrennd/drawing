function objectDelete(object)

% OBJECTDELETE Clear up the graphics that portray and object.
%
%	Description:
%	objectDelete(object)
%% 	objectDelete.m version 1.2


for i = 1:length(object)
  try
    delete(object(i).handle)
  catch
  end
  try
    delete(object(i).controlPointHandle)
  catch
  end
end