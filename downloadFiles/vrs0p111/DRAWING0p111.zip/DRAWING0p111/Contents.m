% DRAWING toolbox
% Version 0.111		29-Oct-2007
% Copyright (c) 2007, Neil D. Lawrence
% 
, Neil D. Lawrence
% OVALCREATE Create a struct containing the parameters of an oval.
% RECTCREATE Create a struct containing the parameters of an rectangle.
% RECTCOPY Copies a rect structure into a new rect structure.
% DRAWCONTROLCALLBACK Call back for the draw control interface.
% MODECONTROLCALLBACK Call back function which controls the selction of the modes.
% RECTMOVE Moves a rect to a new point.
% SQUARE2RECT Converts a struct of the form square to one of the form rect.
% SQUAREDIST Computes the distance between a point and the centre of the square.
% SQUAREMOVE Moves a square to a new point.
% SQUAREDRAW Draw a square.
% CIRCLEDRAW Draws a circle.
% DRAWCALLBACKHANDLER Function for handling call backs from draw window.
% EDITCONTROLWINDOW Script which creates the window with the edit commands.
% RECTDRAW Draw a rectangle.
% CIRCLEDIST Computes the distance between a point and the centre of the circle.
% GRIDCOPY Copies a grid structure into a new grid structure.
% GRIDMOVE Moves a grid to a new point.
% RECTDIST Computes the distance between a point and the centre of the rect.
% IMAGELABEL Incomplete script for drawing shapes on an image.
% ARROW Draw an arrow. 
% CIRCLECREATE Create a struct containing the parameters of an circle.
% OVALDRAW Draw an oval.
% OVALCOPY Copies a oval structure into a new oval structure.
% RECT Create a rectangle.
% GRIDDIST Computes the distance between a point and the centre of the grid.
% CIRCLECOPY Copies a circle structure into a new circle structure.
% OVALDIST Computes the distance between a point and the centre of the oval.
% RECTSUBSCRIPT Returns the subscripts of any pixels that would fall inside the rect.
% OBJECTCOPY Moves an object to a new point.
% SQUARESUBSCRIPT Returns the subscripts of any pixels that would fall inside the square
% CIRCLE2OVAL Converts a struct of the form circle to on of the form oval.
% OBJECTSUBSCRIPT Gives the subscript of pixels which fall within an object.
% OBJECTDELETE Clear up the graphics that portray and object.
% CIRCLESUBSCRIPT Returns the subscripts of any pixels that would fall inside the circle
% SQUARECREATE Create a struct containing the parameters of an square.
% CIRCLE Draw a circle.
% GRIDCREATE Create a structure which stores a grid.
% OBJECTDRAW Draws a object.
% CIRCLEMOVE Moves a circle to a new point.
% OBJECTDIST Computes the distance between an object and a point.
% OVALPERIMETER Returns the subscripts of any pixels that fall on the perimeter of the ovals.
% OVALMOVE Moves a oval to a new point.
% OVAL Creates an oval object.
% SQUARECOPY Copies a square structure into a new square structure.
% GRIDDRAW Draws a grid.
% OBJECTMOVE Moves an object to a new point.
