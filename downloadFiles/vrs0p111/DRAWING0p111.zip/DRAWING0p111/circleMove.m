function circles = circleMove(circles, moveVector);

% CIRCLEMOVE Moves a circle to a new point.
%
%	Description:
%	circles = circleMove(circles, moveVector);
%% 	circleMove.m version 1.2


for i = 1:length(circles)
  circles(i).centre = circles(i).centre + moveVector;
  circles(i) = circleDraw(circles(i));
end