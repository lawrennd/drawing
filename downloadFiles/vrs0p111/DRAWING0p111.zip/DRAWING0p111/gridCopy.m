function newGrid = gridCopy(grid);

% GRIDCOPY Copies a grid structure into a new grid structure.
%
%	Description:
%	newGrid = gridCopy(grid);
%% 	gridCopy.m version 1.2


newGrid = grid;
newGrid.handle = [];
newGrid.controlPointHandle = [];