function [iSub, jSub] = circleSubscript(circles);

% CIRCLESUBSCRIPT Returns the subscripts of any pixels that would fall inside the circle
%
%	Description:
%	[iSub, jSub] = circleSubscript(circles);
%% 	circleSubscript.m version 1.2


ovals = circleToOval(circles);
[iSub, jSub] = ovalSubscript(ovals);


