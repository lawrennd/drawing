function object = objectDraw(object);

% OBJECTDRAW Draws a object.
%
%	Description:
%	object = objectDraw(object);
%% 	objectDraw.m version 1.2


for i = 1:length(object)
  object(i) = feval([object(i).type 'Draw'], object(i));
end