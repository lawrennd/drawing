function newRect = rectCopy(rect);

% RECTCOPY Copies a rect structure into a new rect structure.
%
%	Description:
%	newRect = rectCopy(rect);
%% 	rectCopy.m version 1.2


newRect = rect;
newRect.handle = [];
newRect.controlPointHandle = [];