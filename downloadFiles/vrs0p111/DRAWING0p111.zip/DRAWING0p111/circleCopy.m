function newCircle = circleCopy(circle);

% CIRCLECOPY Copies a circle structure into a new circle structure.
%
%	Description:
%	newCircle = circleCopy(circle);
%% 	circleCopy.m version 1.2


newCircle = circle;
newCircle.handle = [];
newCircle.controlPointHandle = [];