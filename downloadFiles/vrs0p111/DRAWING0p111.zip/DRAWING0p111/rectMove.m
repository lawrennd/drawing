function rects = rectMove(rects, moveVector);

% RECTMOVE Moves a rect to a new point.
%
%	Description:
%	rects = rectMove(rects, moveVector);
%% 	rectMove.m version 1.2


for i = 1:length(rects)
  rects(i).firstPoint = rects(i).firstPoint + moveVector;
  rects(i).secondPoint = rects(i).secondPoint + moveVector;
  rects(i) = rectDraw(rects(i));
end
