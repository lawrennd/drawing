function circles = circleDraw(circles);

% CIRCLEDRAW Draws a circle.
%
%	Description:
%	circles = circleDraw(circles);
%% 	circleDraw.m version 1.2


ovals = circle2oval(circles);
ovals = ovalDraw(ovals);

for i = 1:length(circles)
  circles(i).handle = ovals(i).handle;
  circles(i).controlPointHandle = ovals(i).controlPointHandle;
end