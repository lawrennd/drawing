function squares = squareMove(squares, moveVector);

% SQUAREMOVE Moves a square to a new point.
%
%	Description:
%	squares = squareMove(squares, moveVector);
%% 	squareMove.m version 1.2


for i = 1:length(squares)
  squares(i).centre = squares(i).centre + moveVector;
  squares(i) = squareDraw(squares(i));
end
