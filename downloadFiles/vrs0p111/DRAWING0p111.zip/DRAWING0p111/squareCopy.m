function newSquare = squareCopy(square);

% SQUARECOPY Copies a square structure into a new square structure.
%
%	Description:
%	newSquare = squareCopy(square);
%% 	squareCopy.m version 1.2


newSquare = square;
newSquare.handle = [];
newSquare.controlPointHandle = [];