function [iSub, jSub] = objectSubscript(object);

% OBJECTSUBSCRIPT Gives the subscript of pixels which fall within an object.
%
%	Description:
%	[iSub, jSub] = objectSubscript(object);
%% 	objectSubscript.m version 1.2


[iSub, jSub] = feval([object.type 'Subscript'], object);
