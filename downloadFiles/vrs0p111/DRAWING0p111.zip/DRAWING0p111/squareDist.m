function distance = squareDist(squares, point);

% SQUAREDIST Computes the distance between a point and the centre of the square.
%
%	Description:
%	distance = squareDist(squares, point);
%% 	squareDist.m version 1.2

distance = zeros(length(squares), 1);
for i = 1:length(squares)
  distance(i) = sqrt(dist2(squares(i).centre, point)); 
end
