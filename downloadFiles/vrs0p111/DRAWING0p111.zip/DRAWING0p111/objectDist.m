function distance = objectDist(object, point);

% OBJECTDIST Computes the distance between an object and a point.
%
%	Description:
%	distance = objectDist(object, point);
%% 	objectDist.m version 1.2


distance = feval([object.type 'Dist'], object, point);

