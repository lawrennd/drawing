function handle = circle(centres, radii, handle)

% CIRCLE Draw a circle.
%
%	Description:
%	handle = circle(centres, radii, handle)
%% 	circle.m version 1.2


if nargin < 3
  handle = oval(centres, radii, radii);
else 
  handle = oval(centres, radii, radii, handle);
end
