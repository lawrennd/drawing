function springs = springMove(springs, moveVector);

% SPRINGMOVE Moves a spring to a new point.
%
%	Description:
%	springs = springMove(springs, moveVector);
%% 	springMove.m SVN version 584
% 	last update 2007-11-09T14:05:36.652359Z

for i = 1:length(springs)
  springs(i).start = springs(i).start + moveVector;
  springs(i).end = springs(i).end + moveVector;
  springs(i) = springDraw(springs(i));
end