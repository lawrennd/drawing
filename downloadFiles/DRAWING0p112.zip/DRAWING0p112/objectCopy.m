function newObject = objectCopy(object);

% OBJECTCOPY Moves an object to a new point.
%
%	Description:
%	newObject = objectCopy(object);
%% 	objectCopy.m CVS version 1.3
% 	objectCopy.m SVN version 584
% 	last update 2007-10-29T00:14:32.874672Z

newObject = feval([object.type 'Copy'], object);
