function newSpring = springCopy(spring);

% SPRINGCOPY Copies a spring structure into a new spring structure.
%
%	Description:
%	newSpring = springCopy(spring);
%% 	springCopy.m SVN version 584
% 	last update 2007-11-09T14:05:35.734352Z

newSpring = spring;
newSpring.handle = [];
newSpring.controlPointHandle = [];