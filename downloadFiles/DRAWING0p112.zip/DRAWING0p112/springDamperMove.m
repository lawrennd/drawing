function springDampers = springDamperMove(springDampers, moveVector);

% SPRINGDAMPERMOVE Moves a spring-damper to a new point.
%
%	Description:
%	springDampers = springDamperMove(springDampers, moveVector);
%% 	springDamperMove.m SVN version 584
% 	last update 2007-11-09T14:05:36.101755Z

for i = 1:length(springDampers)
  springDampers(i).start = springDampers(i).start + moveVector;
  springDampers(i).end = springDampers(i).end + moveVector;
  springDampers(i) = springDamperDraw(springDampers(i));
end