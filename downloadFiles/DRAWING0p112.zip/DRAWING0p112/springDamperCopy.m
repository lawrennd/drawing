function newSpringDamper = springDamperCopy(springDamper);

% SPRINGDAMPERCOPY Copies a spring-damper structure into a new spring-damper structure.
%
%	Description:
%	newSpringDamper = springDamperCopy(springDamper);
%% 	springDamperCopy.m SVN version 584
% 	last update 2007-11-09T14:05:35.770557Z

newSpringDamper = springDamper;
newSpringDamper.handle = [];
newSpringDamper.controlPointHandle = [];