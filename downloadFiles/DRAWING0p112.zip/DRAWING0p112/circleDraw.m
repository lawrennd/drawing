function circles = circleDraw(circles);

% CIRCLEDRAW Draws a circle.
%
%	Description:
%	circles = circleDraw(circles);
%% 	circleDraw.m CVS version 1.2
% 	circleDraw.m SVN version 584
% 	last update 2007-10-29T00:14:31.432584Z

ovals = circle2oval(circles);
ovals = ovalDraw(ovals);

for i = 1:length(circles)
  circles(i).handle = ovals(i).handle;
  circles(i).controlPointHandle = ovals(i).controlPointHandle;
end