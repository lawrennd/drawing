function [iSub, jSub] = circleSubscript(circles);

% CIRCLESUBSCRIPT Returns the subscripts of any pixels that would fall inside the circle
%
%	Description:
%	[iSub, jSub] = circleSubscript(circles);
%% 	circleSubscript.m CVS version 1.2
% 	circleSubscript.m SVN version 584
% 	last update 2007-10-29T00:14:31.578649Z

ovals = circleToOval(circles);
[iSub, jSub] = ovalSubscript(ovals);


