function newRect = rectCopy(rect);

% RECTCOPY Copies a rect structure into a new rect structure.
%
%	Description:
%	newRect = rectCopy(rect);
%% 	rectCopy.m CVS version 1.2
% 	rectCopy.m SVN version 584
% 	last update 2007-10-29T00:14:34.545539Z

newRect = rect;
newRect.handle = [];
newRect.controlPointHandle = [];