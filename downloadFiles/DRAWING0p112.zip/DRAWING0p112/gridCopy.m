function newGrid = gridCopy(grid);

% GRIDCOPY Copies a grid structure into a new grid structure.
%
%	Description:
%	newGrid = gridCopy(grid);
%% 	gridCopy.m CVS version 1.2
% 	gridCopy.m SVN version 584
% 	last update 2007-10-29T00:14:32.274059Z

newGrid = grid;
newGrid.handle = [];
newGrid.controlPointHandle = [];