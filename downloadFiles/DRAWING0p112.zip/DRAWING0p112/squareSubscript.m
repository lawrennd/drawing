function [iSub, jSub] = squareSubscript(squares)

% SQUARESUBSCRIPT Returns the subscripts of any pixels that would fall inside the square
%
%	Description:
%	[iSub, jSub] = squareSubscript(squares)
%% 	squareSubscript.m CVS version 1.2
% 	squareSubscript.m SVN version 584
% 	last update 2007-10-29T00:14:36.296510Z

rects = square2rects(squares);
[iSub, jSub] = rectsubscript(rects);