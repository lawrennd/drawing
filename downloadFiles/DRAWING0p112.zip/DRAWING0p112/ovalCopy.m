function newOval = ovalCopy(oval);

% OVALCOPY Copies a oval structure into a new oval structure.
%
%	Description:
%	newOval = ovalCopy(oval);
%% 	ovalCopy.m CVS version 1.2
% 	ovalCopy.m SVN version 584
% 	last update 2007-10-29T00:14:33.807367Z

newOval = oval;
newOval.handle = [];
newOval.controlPointHandle = [];