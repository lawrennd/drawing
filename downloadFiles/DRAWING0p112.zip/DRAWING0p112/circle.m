function handle = circle(centres, radii, handle)

% CIRCLE Draw a circle.
%
%	Description:
%	handle = circle(centres, radii, handle)
%% 	circle.m CVS version 1.2
% 	circle.m SVN version 584
% 	last update 2007-10-29T00:14:31.276178Z

if nargin < 3
  handle = oval(centres, radii, radii);
else 
  handle = oval(centres, radii, radii, handle);
end
