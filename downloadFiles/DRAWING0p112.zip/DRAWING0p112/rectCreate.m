function rect = rectCreate(firstPoint, secondPoint, handle);

% RECTCREATE Create a struct containing the parameters of an rectangle.
%
%	Description:
%	rect = rectCreate(firstPoint, secondPoint, handle);
%% 	rectCreate.m CVS version 1.2
% 	rectCreate.m SVN version 584
% 	last update 2007-10-29T00:14:34.564263Z

rect.firstPoint = firstPoint;
rect.secondPoint = secondPoint;
rect.selected = 1;
if nargin > 2
  rect.handle = handle;
end

rect.type = 'rect';

