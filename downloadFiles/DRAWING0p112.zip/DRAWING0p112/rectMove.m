function rects = rectMove(rects, moveVector);

% RECTMOVE Moves a rect to a new point.
%
%	Description:
%	rects = rectMove(rects, moveVector);
%% 	rectMove.m CVS version 1.2
% 	rectMove.m SVN version 584
% 	last update 2007-10-29T00:14:34.918597Z

for i = 1:length(rects)
  rects(i).firstPoint = rects(i).firstPoint + moveVector;
  rects(i).secondPoint = rects(i).secondPoint + moveVector;
  rects(i) = rectDraw(rects(i));
end
