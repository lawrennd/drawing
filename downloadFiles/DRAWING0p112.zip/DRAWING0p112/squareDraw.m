function squares = squareDraw(squares);

% SQUAREDRAW Draw a square.
%
%	Description:
%	squares = squareDraw(squares);
%% 	squareDraw.m CVS version 1.2
% 	squareDraw.m SVN version 584
% 	last update 2007-10-29T00:14:36.017847Z

rects = square2rect(squares);
rects = rectDraw(rects);
for i = 1:length(squares)
  squares(i).handle = rects(i).handle;
  squares(i).controlPointHandle = rects(i).controlPointHandle;
end