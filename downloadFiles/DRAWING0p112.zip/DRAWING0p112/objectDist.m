function distance = objectDist(object, point);

% OBJECTDIST Computes the distance between an object and a point.
%
%	Description:
%	distance = objectDist(object, point);
%% 	objectDist.m CVS version 1.2
% 	objectDist.m SVN version 584
% 	last update 2007-10-29T00:14:33.680026Z

distance = feval([object.type 'Dist'], object, point);

