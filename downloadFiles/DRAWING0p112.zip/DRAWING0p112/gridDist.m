function distance = gridDist(grids, point);

% GRIDDIST Computes the distance between a point and the centre of the grid.
%
%	Description:
%	distance = gridDist(grids, point);
%% 	gridDist.m CVS version 1.2
% 	gridDist.m SVN version 584
% 	last update 2007-10-29T00:14:32.304910Z

distance = zeros(length(grids), 1);
for i = 1:length(grids)
  grids(i).type = 'rect';
  distance(i) = rectDist(grids(i), point);
  grids(i).type = 'grid';
end
