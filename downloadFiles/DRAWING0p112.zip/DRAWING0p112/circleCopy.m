function newCircle = circleCopy(circle);

% CIRCLECOPY Copies a circle structure into a new circle structure.
%
%	Description:
%	newCircle = circleCopy(circle);
%% 	circleCopy.m CVS version 1.2
% 	circleCopy.m SVN version 584
% 	last update 2007-10-29T00:14:31.342533Z

newCircle = circle;
newCircle.handle = [];
newCircle.controlPointHandle = [];