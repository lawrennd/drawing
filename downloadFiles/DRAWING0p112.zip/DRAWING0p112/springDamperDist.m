function distance = springDamperDist(springDampers, point);

% SPRINGDAMPERDIST Computes the distance between a point and the centre of the spring-damper.
%
%	Description:
%	distance = springDamperDist(springDampers, point);
%% 	springDamperDist.m SVN version 584
% 	last update 2007-11-09T14:05:36.069375Z

  
distance = zeros(length(springDampers), 1);
for i = 1:length(springDampers)
  centre = springDampers(i).start + (springDampers(i).end - springDampers(i).start)/2;
  distance(i) = sqrt(dist2(centre, point(i, :)));
end
