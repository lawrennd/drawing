function spring = springCreate(startPoint, endPoint, width, bars, constant, handle)

% SPRINGCREATE Create a struct containing the parameters of a spring.
%
%	Description:
%	spring = springCreate(startPoint, endPoint, width, bars, constant, handle)
%% 	springCreate.m SVN version 584
% 	last update 2007-11-09T14:05:35.752452Z

spring.start = startPoint;
spring.end = endPoint;
spring.width = width;

spring.constant = constant;
spring.bars = bars;
if bars < 1
  error('Spring must have at least one bar.');
end
spring.selected = 1;

spring.handle = [];
if nargin > 5
  spring.handle = handle;
end
spring.controlPointHandle = [];
spring.type = 'spring';




