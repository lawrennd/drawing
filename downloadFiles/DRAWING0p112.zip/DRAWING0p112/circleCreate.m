function circle = circleCreate(centre, radius, handle);

% CIRCLECREATE Create a struct containing the parameters of a circle.
%
%	Description:
%	circle = circleCreate(centre, radius, handle);
%% 	circleCreate.m CVS version 1.3
% 	circleCreate.m SVN version 584
% 	last update 2007-11-09T14:05:35.596145Z

circle.radius = radius;
circle.centre = centre;

circle.selected = 1;

circle.handle = [];
if nargin > 3
  circle.handle = handle;
end
circle.controlPointHandle = [];
circle.type = 'circle';




