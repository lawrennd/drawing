function newDamper = damperCopy(damper);

% DAMPERCOPY Copies a damper structure into a new damper structure.
%
%	Description:
%	newDamper = damperCopy(damper);
%% 	damperCopy.m SVN version 584
% 	last update 2007-11-09T14:05:35.613629Z

newDamper = damper;
newDamper.handle = [];
newDamper.controlPointHandle = [];