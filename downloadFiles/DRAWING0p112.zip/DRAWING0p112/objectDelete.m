function objectDelete(object)

% OBJECTDELETE Clear up the graphics that portray and object.
%
%	Description:
%	objectDelete(object)
%% 	objectDelete.m CVS version 1.2
% 	objectDelete.m SVN version 584
% 	last update 2007-10-29T00:14:33.667788Z

for i = 1:length(object)
  try
    delete(object(i).handle)
  catch
  end
  try
    delete(object(i).controlPointHandle)
  catch
  end
end