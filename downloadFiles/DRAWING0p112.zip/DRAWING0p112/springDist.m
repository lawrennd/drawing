function distance = springDist(springs, point);

% SPRINGDIST Computes the distance between a point and the centre of the spring.
%
%	Description:
%	distance = springDist(springs, point);
%% 	springDist.m SVN version 584
% 	last update 2007-11-09T14:05:36.568818Z

  
distance = zeros(length(springs), 1);
for i = 1:length(springs)
  centre = springs(i).start + (springs(i).end - springs(i).start)/2;
  distance(i) = sqrt(dist2(centre, point(i, :)));
end
