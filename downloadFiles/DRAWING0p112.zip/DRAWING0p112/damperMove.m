function dampers = damperMove(dampers, moveVector);

% DAMPERMOVE Moves a damper to a new point.
%
%	Description:
%	dampers = damperMove(dampers, moveVector);
%% 	damperMove.m SVN version 584
% 	last update 2007-11-09T14:05:35.686162Z

for i = 1:length(dampers)
  dampers(i).start = dampers(i).start + moveVector;
  dampers(i).end = dampers(i).end + moveVector;
  dampers(i) = damperDraw(dampers(i));
end