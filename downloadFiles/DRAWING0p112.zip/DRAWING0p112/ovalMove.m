function ovals = ovalMove(ovals, moveVector);

% OVALMOVE Moves a oval to a new point.
%
%	Description:
%	ovals = ovalMove(ovals, moveVector);
%% 	ovalMove.m CVS version 1.2
% 	ovalMove.m SVN version 584
% 	last update 2007-10-29T00:14:34.369818Z

for i = 1:length(ovals)
  ovals(i).centre = ovals(i).centre + moveVector;
  ovals(i) = ovalDraw(ovals(i));
end