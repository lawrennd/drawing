function object = objectMove(object, moveVector);

% OBJECTMOVE Moves an object to a new point.
%
%	Description:
%	object = objectMove(object, moveVector);
%% 	objectMove.m CVS version 1.2
% 	objectMove.m SVN version 584
% 	last update 2007-10-29T00:14:33.740080Z

object = feval([object.type 'Move'], object, moveVector);
