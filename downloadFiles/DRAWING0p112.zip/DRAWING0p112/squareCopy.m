function newSquare = squareCopy(square);

% SQUARECOPY Copies a square structure into a new square structure.
%
%	Description:
%	newSquare = squareCopy(square);
%% 	squareCopy.m CVS version 1.2
% 	squareCopy.m SVN version 584
% 	last update 2007-10-29T00:14:35.963646Z

newSquare = square;
newSquare.handle = [];
newSquare.controlPointHandle = [];