function squares = squareMove(squares, moveVector);

% SQUAREMOVE Moves a square to a new point.
%
%	Description:
%	squares = squareMove(squares, moveVector);
%% 	squareMove.m CVS version 1.2
% 	squareMove.m SVN version 584
% 	last update 2007-10-29T00:14:36.035934Z

for i = 1:length(squares)
  squares(i).centre = squares(i).centre + moveVector;
  squares(i) = squareDraw(squares(i));
end
