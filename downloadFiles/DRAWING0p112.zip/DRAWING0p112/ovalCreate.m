function oval = ovalCreate(centre, xradius, yradius, handle);

% OVALCREATE Create a struct containing the parameters of an oval.
%
%	Description:
%	oval = ovalCreate(centre, xradius, yradius, handle);
%% 	ovalCreate.m CVS version 1.2
% 	ovalCreate.m SVN version 584
% 	last update 2007-10-29T00:14:33.825341Z

oval.xradius = xradius;
oval.yradius = yradius;
oval.selected = 1;
oval.centre = centre;
oval.handle = [];
if nargin > 3
  oval.handle = handle;
end
oval.controlPointHandle = [];
oval.type = 'oval';

