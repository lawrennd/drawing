function distance = squareDist(squares, point);

% SQUAREDIST Computes the distance between a point and the centre of the square.
%
%	Description:
%	distance = squareDist(squares, point);
%% 	squareDist.m CVS version 1.2
% 	squareDist.m SVN version 584
% 	last update 2007-10-29T00:14:35.999856Z
distance = zeros(length(squares), 1);
for i = 1:length(squares)
  distance(i) = sqrt(dist2(squares(i).centre, point)); 
end
