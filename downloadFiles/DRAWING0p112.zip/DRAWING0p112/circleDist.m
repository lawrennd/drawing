function distance = circleDist(circles, point);

% CIRCLEDIST Computes the distance between a point and the centre of the circle.
%
%	Description:
%	distance = circleDist(circles, point);
%% 	circleDist.m CVS version 1.2
% 	circleDist.m SVN version 584
% 	last update 2007-10-29T00:14:31.420847Z
distance = zeros(length(circles), 1);
for i = 1:length(circles)
  distance(i) = sqrt(dist2(circles(i).centre, point(i, :)));
end
