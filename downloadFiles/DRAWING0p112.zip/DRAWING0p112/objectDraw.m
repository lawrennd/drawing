function object = objectDraw(object);

% OBJECTDRAW Draws a object.
%
%	Description:
%	object = objectDraw(object);
%% 	objectDraw.m CVS version 1.2
% 	objectDraw.m SVN version 584
% 	last update 2007-10-29T00:14:33.726257Z

for i = 1:length(object)
  object(i) = feval([object(i).type 'Draw'], object(i));
end