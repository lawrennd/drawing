function distance = ovalDist(ovals, point);

% OVALDIST Computes the distance between a point and the centre of the oval.
%
%	Description:
%	distance = ovalDist(ovals, point);
%% 	ovalDist.m CVS version 1.2
% 	ovalDist.m SVN version 584
% 	last update 2007-10-29T00:14:34.328636Z
distance = zeros(length(ovals), 1);
for i = 1:length(ovals)
  distance(i) = sqrt(dist2(ovals(i).centre, point(i, :)));
end
