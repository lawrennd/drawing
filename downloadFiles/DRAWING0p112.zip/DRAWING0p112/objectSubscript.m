function [iSub, jSub] = objectSubscript(object);

% OBJECTSUBSCRIPT Gives the subscript of pixels which fall within an object.
%
%	Description:
%	[iSub, jSub] = objectSubscript(object);
%% 	objectSubscript.m CVS version 1.2
% 	objectSubscript.m SVN version 584
% 	last update 2007-10-29T00:14:33.752685Z

[iSub, jSub] = feval([object.type 'Subscript'], object);
