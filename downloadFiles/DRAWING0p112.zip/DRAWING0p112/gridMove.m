function grids = gridMove(grids, moveVector);

% GRIDMOVE Moves a grid to a new point.
%
%	Description:
%	grids = gridMove(grids, moveVector);
%% 	gridMove.m CVS version 1.2
% 	gridMove.m SVN version 584
% 	last update 2007-10-29T00:14:32.612936Z

for i = 1:length(grids)
  grids(i).firstPoint = grids(i).firstPoint + moveVector;
  grids(i).secondPoint = grids(i).secondPoint + moveVector;
  grids(i) = gridDraw(grids(i));
end