function distance = gridDist(grids, point);

% GRIDDIST Computes the distance between a point and the centre of the grid.
%
% distance = gridDist(grids, point);
%

% Copyright (c) 2005 Neil D. Lawrence
% gridDist.m version 1.1



distance = zeros(length(grids), 1);
for i = 1:length(grids)
  grids(i).type = 'rect';
  distance(i) = rectDist(grids(i), point);
  grids(i).type = 'grid';
end
