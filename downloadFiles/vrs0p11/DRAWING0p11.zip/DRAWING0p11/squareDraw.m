function squares = squareDraw(squares);

% SQUAREDRAW Draw a square.
%
% squares = squareDraw(squares);
%

% Copyright (c) 2005 Neil D. Lawrence
% squareDraw.m version 1.1



rects = square2rect(squares);
rects = rectDraw(rects);
for i = 1:length(squares)
  squares(i).handle = rects(i).handle;
  squares(i).controlPointHandle = rects(i).controlPointHandle;
end