function rect = rectCreate(firstPoint, secondPoint, handle);

% RECTCREATE Create a struct containing the parameters of an rectangle.
%
% rect = rectCreate(firstPoint, secondPoint, handle);
%

% Copyright (c) 2005 Neil D. Lawrence
% rectCreate.m version 1.1



rect.firstPoint = firstPoint;
rect.secondPoint = secondPoint;
rect.selected = 1;
if nargin > 2
  rect.handle = handle;
end

rect.type = 'rect';

