function rects = rectMove(rects, moveVector);

% RECTMOVE Moves a rect to a new point.
%
% rects = rectMove(rects, moveVector);
%

% Copyright (c) 2005 Neil D. Lawrence
% rectMove.m version 1.1



for i = 1:length(rects)
  rects(i).firstPoint = rects(i).firstPoint + moveVector;
  rects(i).secondPoint = rects(i).secondPoint + moveVector;
  rects(i) = rectDraw(rects(i));
end
