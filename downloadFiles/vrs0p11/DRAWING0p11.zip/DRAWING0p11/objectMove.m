function object = objectMove(object, moveVector);

% OBJECTMOVE Moves an object to a new point.
%
% object = objectMove(object, moveVector);
%

% Copyright (c) 2005 Neil D. Lawrence
% objectMove.m version 1.1



object = feval([object.type 'Move'], object, moveVector);
