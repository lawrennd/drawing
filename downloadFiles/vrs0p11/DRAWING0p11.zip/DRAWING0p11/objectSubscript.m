function [iSub, jSub] = objectSubscript(object);

% OBJECTSUBSCRIPT Gives the subscript of pixels which fall within an object.
%
% [iSub, jSub] = objectSubscript(object);
%

% Copyright (c) 2005 Neil D. Lawrence
% objectSubscript.m version 1.1



[iSub, jSub] = feval([object.type 'Subscript'], object);
