function grid = gridCreate(firstPoint, secondPoint, gridRows, gridCols, handle);

% GRIDCREATE Create a structure which stores a grid.
%
% grid = gridCreate(firstPoint, secondPoint, gridRows, gridCols, handle);
%

% Copyright (c) 2005 Neil D. Lawrence
% gridCreate.m version 1.1



grid.firstPoint = firstPoint;
grid.secondPoint = secondPoint;

grid.numRows = gridRows;
grid.numColumns = gridCols;

grid.selected = 1;

grid.handle = [];
if nargin > 4
  grid.handle = handle;
end
grid.controlPointHandle = [];

grid.type = 'grid';











