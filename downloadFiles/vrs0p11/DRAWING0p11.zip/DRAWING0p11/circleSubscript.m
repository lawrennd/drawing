function [iSub, jSub] = circleSubscript(circles);

% CIRCLESUBSCRIPT Returns the subscripts of any pixels that would fall inside the circle
%
% [iSub, jSub] = circleSubscript(circles);
%

% Copyright (c) 2005 Neil D. Lawrence
% circleSubscript.m version 1.1



ovals = circleToOval(circles);
[iSub, jSub] = ovalSubscript(ovals);


