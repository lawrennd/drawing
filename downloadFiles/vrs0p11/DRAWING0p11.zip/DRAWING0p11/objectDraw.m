function object = objectDraw(object);

% OBJECTDRAW Draws a object.
%
% object = objectDraw(object);
%

% Copyright (c) 2005 Neil D. Lawrence
% objectDraw.m version 1.1



object = feval([object.type 'Draw'], object);
