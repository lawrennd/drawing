function circles = circleDraw(circles);

% CIRCLEDRAW Draws a circle.
%
% circles = circleDraw(circles);
%

% Copyright (c) 2005 Neil D. Lawrence
% circleDraw.m version 1.1



ovals = circle2oval(circles);
ovals = ovalDraw(ovals);

for i = 1:length(circles)
  circles(i).handle = ovals(i).handle;
  circles(i).controlPointHandle = ovals(i).controlPointHandle;
end