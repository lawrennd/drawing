function square = squareCreate(centre, width, handle);

% SQUARECREATE Create a struct containing the parameters of an square.
%
% square = squareCreate(centre, width, handle);
%

% Copyright (c) 2005 Neil D. Lawrence
% squareCreate.m version 1.1



square.width = width;
square.centre = centre;
square.selected = 1;
if nargin > 2
  square.handle = handle;
end
square.type = 'square';

