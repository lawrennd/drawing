function handle = circle(centres, radii, handle)

% CIRCLE Draw a circle.
%
% handle = circle(centres, radii, handle)
%

% Copyright (c) 2005 Neil D. Lawrence
% circle.m version 1.1



if nargin < 3
  handle = oval(centres, radii, radii);
else 
  handle = oval(centres, radii, radii, handle);
end
