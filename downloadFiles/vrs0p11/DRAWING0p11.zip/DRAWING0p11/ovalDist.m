function distance = ovalDist(ovals, point);

% OVALDIST Computes the distance between a point and the centre of the oval.
%
% distance = ovalDist(ovals, point);
%

% Copyright (c) 2005 Neil D. Lawrence
% ovalDist.m version 1.1


distance = zeros(length(ovals), 1);
for i = 1:length(ovals)
  distance(i) = sqrt(dist2(ovals(i).centre, point(i, :)));
end
