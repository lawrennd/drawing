function newCircle = circleCopy(circle);

% CIRCLECOPY Copies a circle structure into a new circle structure.
%
% newCircle = circleCopy(circle);
%

% Copyright (c) 2005 Neil D. Lawrence
% circleCopy.m version 1.1



newCircle = circle;
newCircle.handle = [];
newCircle.controlPointHandle = [];