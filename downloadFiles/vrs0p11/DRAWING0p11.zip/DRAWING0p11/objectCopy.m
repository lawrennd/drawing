function newObject = objectCopy(object);

% OBJECTMOVE Moves an object to a new point.
%
% newObject = objectCopy(object);
%

% Copyright (c) 2005 Neil D. Lawrence
% objectCopy.m version 1.1



newObject = feval([object.type 'Copy'], object);
