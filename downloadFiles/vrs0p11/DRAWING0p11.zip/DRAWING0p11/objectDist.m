function distance = objectDist(object, point);

% OBJECTDIST Computes the distance between an object and a point.
%
% distance = objectDist(object, point);
%

% Copyright (c) 2005 Neil D. Lawrence
% objectDist.m version 1.1



distance = feval([object.type 'Dist'], object, point);

