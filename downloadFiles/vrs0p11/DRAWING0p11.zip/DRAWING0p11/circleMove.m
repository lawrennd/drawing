function circles = circleMove(circles, moveVector);

% CIRCLEMOVE Moves a circle to a new point.
%
% circles = circleMove(circles, moveVector);
%

% Copyright (c) 2005 Neil D. Lawrence
% circleMove.m version 1.1



for i = 1:length(circles)
  circles(i).centre = circles(i).centre + moveVector;
  circles(i) = circleDraw(circles(i));
end