function distance = squareDist(squares, point);

% SQUAREDIST Computes the distance between a point and the centre of the square.
%
% distance = squareDist(squares, point);
%

% Copyright (c) 2005 Neil D. Lawrence
% squareDist.m version 1.1


distance = zeros(length(squares), 1);
for i = 1:length(squares)
  distance(i) = sqrt(dist2(squares(i).centre, point)); 
end
