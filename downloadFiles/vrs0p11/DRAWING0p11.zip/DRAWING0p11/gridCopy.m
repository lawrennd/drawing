function newGrid = gridCopy(grid);

% GRIDCOPY Copies a grid structure into a new grid structure.
%
% newGrid = gridCopy(grid);
%

% Copyright (c) 2005 Neil D. Lawrence
% gridCopy.m version 1.1



newGrid = grid;
newGrid.handle = [];
newGrid.controlPointHandle = [];