function squares = squareMove(squares, moveVector);

% SQUAREMOVE Moves a square to a new point.
%
% squares = squareMove(squares, moveVector);
%

% Copyright (c) 2005 Neil D. Lawrence
% squareMove.m version 1.1



for i = 1:length(squares)
  squares(i).centre = squares(i).centre + moveVector;
  squares(i) = squareDraw(squares(i));
end
