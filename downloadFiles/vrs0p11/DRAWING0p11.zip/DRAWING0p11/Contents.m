% DRAWING toolbox
% Version 0.11		Sunday 20 Nov 2005 at 19:55
% Copyright (c) 2005 Neil D. Lawrence
% 
% ARROW Draw an arrow. 
% CIRCLE Draw a circle.
% CIRCLE2OVAL Converts a struct of the form circle to on of the form oval.
% CIRCLECOPY Copies a circle structure into a new circle structure.
% CIRCLECREATE Create a struct containing the parameters of an circle.
% CIRCLEDIST Computes the distance between a point and the centre of the circle.
% CIRCLEDRAW Draws a circle.
% CIRCLEMOVE Moves a circle to a new point.
% CIRCLESUBSCRIPT Returns the subscripts of any pixels that would fall inside the circle
% DRAWCALLBACKHANDLER Function for handling call backs from draw window.
% DRAWCONTROLCALLBACK Call back for the draw control interface.
% EDITCONTROLWINDOW Script which creates the window with the edit commands.
% GRIDCOPY Copies a grid structure into a new grid structure.
% GRIDCREATE Create a structure which stores a grid.
% GRIDDIST Computes the distance between a point and the centre of the grid.
% GRIDDRAW Draws a grid.
% GRIDMOVE Moves a grid to a new point.
% IMAGELABEL Incomplete script for drawing shapes on an image.
% MODECONTROLCALLBACK Call back function which controls the selction of the modes.
% OBJECTMOVE Moves an object to a new point.
% OBJECTDELETE Clear up the graphics that portray and object.
% OBJECTDIST Computes the distance between an object and a point.
% OBJECTDRAW Draws a object.
% OBJECTMOVE Moves an object to a new point.
% OBJECTSUBSCRIPT Gives the subscript of pixels which fall within an object.
% OVAL Creates an oval object.
% OVALCOPY Copies a oval structure into a new oval structure.
% OVALCREATE Create a struct containing the parameters of an oval.
% OVALDIST Computes the distance between a point and the centre of the oval.
% OVALDRAW Draw an oval.
% OVALMOVE Moves a oval to a new point.
% OVALPERIMETER Returns the subscripts of any pixels that fall on the perimeter of the ovals.
% RECT Create a rectangle.
% RECTCOPY Copies a rect structure into a new rect structure.
% RECTCREATE Create a struct containing the parameters of an rectangle.
% RECTDIST Computes the distance between a point and the centre of the rect.
% RECTDRAW Draw a rectangle.
% RECTMOVE Moves a rect to a new point.
% RECTSUBSCRIPT Returns the subscripts of any pixels that would fall inside the rect.
% SQUARE2RECT Converts a struct of the form square to one of the form rect.
% SQUARECOPY Copies a square structure into a new square structure.
% SQUARECREATE Create a struct containing the parameters of an square.
% SQUAREDIST Computes the distance between a point and the centre of the square.
% SQUAREDRAW Draw a square.
% SQUAREMOVE Moves a square to a new point.
% SQUARESUBSCRIPT Returns the subscripts of any pixels that would fall inside the square
