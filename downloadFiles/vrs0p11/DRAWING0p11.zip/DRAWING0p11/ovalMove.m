function ovals = ovalMove(ovals, moveVector);

% OVALMOVE Moves a oval to a new point.
%
% ovals = ovalMove(ovals, moveVector);
%

% Copyright (c) 2005 Neil D. Lawrence
% ovalMove.m version 1.1



for i = 1:length(ovals)
  ovals(i).centre = ovals(i).centre + moveVector;
  ovals(i) = ovalDraw(ovals(i));
end