function newSquare = squareCopy(square);

% SQUARECOPY Copies a square structure into a new square structure.
%
% newSquare = squareCopy(square);
%

% Copyright (c) 2005 Neil D. Lawrence
% squareCopy.m version 1.1



newSquare = square;
newSquare.handle = [];
newSquare.controlPointHandle = [];