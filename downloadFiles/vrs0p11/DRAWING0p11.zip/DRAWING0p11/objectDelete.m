function objectDelete(object)

% OBJECTDELETE Clear up the graphics that portray and object.
%
% objectDelete(object)
%

% Copyright (c) 2005 Neil D. Lawrence
% objectDelete.m version 1.1



for i = 1:length(object)
  try
    delete(object(i).handle)
  catch
  end
  try
    delete(object(i).controlPointHandle)
  catch
  end
end