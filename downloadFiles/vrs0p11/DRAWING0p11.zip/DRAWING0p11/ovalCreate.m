function oval = ovalCreate(centre, xradius, yradius, handle);

% OVALCREATE Create a struct containing the parameters of an oval.
%
% oval = ovalCreate(centre, xradius, yradius, handle);
%

% Copyright (c) 2005 Neil D. Lawrence
% ovalCreate.m version 1.1



oval.xradius = xradius;
oval.yradius = yradius;
oval.selected = 1;
oval.centre = centre;
oval.handle = [];
if nargin > 3
  oval.handle = handle;
end
oval.controlPointHandle = [];
oval.type = 'oval';

