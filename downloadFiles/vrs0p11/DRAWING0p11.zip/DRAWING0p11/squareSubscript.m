function [iSub, jSub] = squareSubscript(squares)
% SQUARESUBSCRIPT Returns the subscripts of any pixels that would fall inside the square
%
% [iSub, jSub] = squareSubscript(squares)
%

% Copyright (c) 2005 Neil D. Lawrence
% squareSubscript.m version 1.1



rects = square2rects(squares);
[iSub, jSub] = rectsubscript(rects);